import React, { useState, useEffect, useCallback } from "react";
import Sidebar from "./components/layout/Sidebar";
import TopHeader from "./components/layout/TopHeader";
import TimetableGenerator from "./components/scheduler/TimetableGenerator";
import FacultyStaffList from "./components/faculty/FacultyStaffList";
import LeaveAndSubstitutions from "./components/substitutions/LeaveAndSubstitutions";
import Modal from "./components/common/Modal";
import Login from "./components/auth/Login";

import { useAuth } from "./context/AuthContext";
import { facultyApi, roomsApi, subjectsApi, timetableApi, leaveApi } from "./api/resources";
import { ApiError } from "./api/client";
import {
  facultyFromApi,
  roomsFromApi,
  subjectsFromApi,
  timetableFromApi,
  byId,
} from "./utils/liveDataAdapter";

import {
  INITIAL_ROLES,
  INITIAL_FACULTY,
  INITIAL_SUBJECTS,
  INITIAL_TIMETABLE,
  INITIAL_ROOMS,
  INITIAL_LEAVE_REQUESTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_SEMESTER_CONFIG
} from "./data/mockData";

export default function App() {
  const { user, loading, logout } = useAuth();
  const [demoMode, setDemoMode] = useState(false);

  const [currentRole, setCurrentRole] = useState("ADMIN");
  const [currentTab, setCurrentTab] = useState("scheduling-engine");
  const [selectedDepartment, setSelectedDepartment] = useState("Computer Science & IT");
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);

  // Application Data States — seeded with mock data so the UI always has
  // something to render; overwritten with real API data once logged in.
  const [facultyList, setFacultyList] = useState(INITIAL_FACULTY);
  const [subjects, setSubjects] = useState(INITIAL_SUBJECTS);
  const [timetable, setTimetable] = useState(INITIAL_TIMETABLE);
  const [rooms, setRooms] = useState(INITIAL_ROOMS);
  const [leaveRequests, setLeaveRequests] = useState(INITIAL_LEAVE_REQUESTS);
  const [auditLogs, setAuditLogs] = useState(INITIAL_AUDIT_LOGS);
  const [semesterConfig, setSemesterConfig] = useState(INITIAL_SEMESTER_CONFIG);

  const liveMode = !!user;

  // Once authenticated, adopt the account's real role and department, and
  // pull real collections from the backend in place of the mock seed data.
  // If any call fails (backend up but empty/misconfigured), we silently
  // keep whatever's already in state rather than breaking the screen.
  useEffect(() => {
    if (!user) return;
    setCurrentRole((user.role || "student").toUpperCase());
    if (user.department) setSelectedDepartment(user.department);

    (async () => {
      try {
        const [apiFaculty, apiRooms, apiSubjects, apiLeave] = await Promise.all([
          facultyApi.list(),
          roomsApi.list(),
          subjectsApi.list(),
          leaveApi.list(),
        ]);
        const subjById = byId(apiSubjects);
        setFacultyList(facultyFromApi(apiFaculty, subjById));
        setRooms(roomsFromApi(apiRooms));
        setSubjects(subjectsFromApi(apiSubjects, byId(apiFaculty), byId(apiRooms)));
        setLeaveRequests(
          apiLeave.map((l) => ({
            id: l.id,
            facultyName: l.faculty_name,
            reason: l.reason,
            slot: l.slot_label,
            status: l.status,
            recommendedProxy: l.recommended_proxy,
            assignedProxy: l.assigned_proxy,
          }))
        );
      } catch {
        // Backend reachable for login but a collection call failed (e.g.
        // nothing seeded yet) — keep the mock seed data visible.
      }
    })();
  }, [user]);

  const currentUser = liveMode
    ? {
        id: user.id,
        name: user.email,
        title: user.role.charAt(0).toUpperCase() + user.role.slice(1),
        badge: user.is_committee_member ? "Committee Member" : user.role,
        dept: user.department || selectedDepartment,
        avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(user.email)}`,
      }
    : INITIAL_ROLES[currentRole] || INITIAL_ROLES.ADMIN;

  // Handlers
  const handleRoleChange = (role) => {
    setCurrentRole(role);
    // The scheduler is the primary workspace for every role for now.
    // There is no dashboard route in this application.
    setCurrentTab("scheduling-engine");
  };

  const handleAssignProxy = (leaveId, proxyName) => {
    setLeaveRequests((prev) =>
      prev.map((lr) =>
        lr.id === leaveId
          ? { ...lr, status: "APPROVED", assignedProxy: proxyName }
          : lr
      )
    );

    // Update timetable proxy assignment for Mon Period 2
    setTimetable((prev) => ({
      ...prev,
      Mon: prev.Mon.map((slot) =>
        slot.subject.includes("DBMS") || slot.id === "t-2"
          ? { ...slot, proxy: proxyName, type: "Ongoing" }
          : slot
      ),
    }));

    // Add to Audit Log
    const newLog = {
      id: `a-${Date.now()}`,
      type: "success",
      title: `Proxy Substitution Assigned: ${proxyName}`,
      desc: `DBMS Theory period covered with zero clashes • Confirmed by Admin`,
      time: "Just now",
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const handleApplyLeave = (newLeave) => {
    setLeaveRequests((prev) => [newLeave, ...prev]);

    const newLog = {
      id: `a-${Date.now()}`,
      type: "error",
      title: `Academic Leave Requested by ${newLeave.facultyName}`,
      desc: `${newLeave.reason} for ${newLeave.slot} • Heuristic proxy solver engaged`,
      time: "Just now",
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const handleAcceptSubstitution = (leaveId) => {
    handleAssignProxy(leaveId, "Prof. Sneha Sharma");
  };

  const handleDeclineSubstitution = (leaveId) => {
    setLeaveRequests((prev) =>
      prev.map((lr) =>
        lr.id === leaveId
          ? { ...lr, recommendedProxy: "Prof. S. Patil" }
          : lr
      )
    );
  };

  const refreshLiveAcademicData = useCallback(async () => {
    if (!liveMode) return;
    const [apiFaculty, apiRooms, apiSubjects, apiLeave] = await Promise.all([
      facultyApi.list(),
      roomsApi.list(),
      subjectsApi.list(),
      leaveApi.list(),
    ]);
    const subjById = byId(apiSubjects);
    setFacultyList(facultyFromApi(apiFaculty, subjById));
    setRooms(roomsFromApi(apiRooms));
    setSubjects(subjectsFromApi(apiSubjects, byId(apiFaculty), byId(apiRooms)));
    setLeaveRequests(apiLeave.map((l) => ({
      id: l.id, facultyName: l.faculty_name, reason: l.reason, slot: l.slot_label,
      status: l.status, recommendedProxy: l.recommended_proxy, assignedProxy: l.assigned_proxy,
    })));
  }, [liveMode]);

  const handleUpdateSubject = async (id, updates) => {
    if (!liveMode) {
      setSubjects((prev) => prev.map((s) => s.id === id ? { ...s, ...updates } : s));
      return;
    }
    const current = subjects.find((s) => s.id === id);
    if (!current) return;
    const payload = {
      name: updates.name ?? current.name,
      code: updates.code ?? current.code ?? "",
      department: updates.department ?? current.department ?? selectedDepartment,
      semester: updates.semester ?? current.semester ?? "Sem 1",
      faculty_id: updates.facultyId ?? current.facultyId,
      hours_per_week: Number(updates.hoursPerWeek ?? current.hoursPerWeek ?? current.totalHours ?? 1),
      requires_lab: updates.requiresLab ?? current.requiresLab ?? false,
      student_count: Number(updates.studentCount ?? current.studentCount ?? 0),
    };
    await subjectsApi.update(id, payload);
    await refreshLiveAcademicData();
  };

  const handleDeleteSubject = async (id) => {
    if (liveMode) {
      await subjectsApi.remove(id);
      await refreshLiveAcademicData();
    } else {
      setSubjects((prev) => prev.filter((s) => s.id !== id));
    }
  };

  const handleAddFaculty = async ({ name, department, maxClassesPerDay = 6 }) => {
    if (liveMode) {
      const created = await facultyApi.create({
        name: name.trim(), department: department || selectedDepartment,
        subject_ids: [], unavailable: [], max_classes_per_day: Number(maxClassesPerDay) || 6, user_id: null,
      });
      await refreshLiveAcademicData();
      return created;
    }
    const created = {
      id: `faculty-${Date.now()}`, name: name.trim(), department: department || selectedDepartment,
      subjects: [], workload: 0, maxWorkload: (Number(maxClassesPerDay) || 6) * 6,
      maxClassesPerDay: Number(maxClassesPerDay) || 6, role: department || selectedDepartment, status: "On Campus",
    };
    setFacultyList((prev) => [...prev, created]);
    return created;
  };

  const handleLoadTimetable = useCallback(async (department, semester) => {
    if (!liveMode) return;
    try {
      const result = await timetableApi.get(department, semester);
      setTimetable(timetableFromApi(result, {
        facultyById: byId(facultyList), subjectsById: byId(subjects), roomsById: byId(rooms),
      }));
    } catch {
      setTimetable({ Mon: [], Tue: [], Wed: [], Thu: [], Fri: [], Sat: [] });
    }
  }, [liveMode, facultyList, subjects, rooms]);

  const handleAddSubject = async (newSub) => {
    if (liveMode) {
      // Persist subjects in MongoDB; React state alone is not enough because
      // the scheduling engine reads its inputs from the backend database.
      const created = await subjectsApi.create({
        name: newSub.name,
        code: newSub.code || "",
        department: newSub.department,
        semester: newSub.semester,
        faculty_id: newSub.facultyId,
        hours_per_week: newSub.hoursPerWeek,
        requires_lab: newSub.requiresLab,
        student_count: newSub.studentCount || 0,
      });
      await refreshLiveAcademicData();
      setAuditLogs((prev) => [{
        id: `a-${Date.now()}`,
        type: "primary",
        title: `Subject saved: ${created.name}`,
        desc: `${created.hours_per_week} hrs/week assigned to ${newSub.facultyName || created.faculty_id}`,
        time: "Just now",
      }, ...prev]);
      return;
    }

    setSubjects((prev) => [...prev, newSub]);
    setAuditLogs((prev) => [{
      id: `a-${Date.now()}`,
      type: "primary",
      title: `New Subject Workload Added: ${newSub.name}`,
      desc: `${newSub.hoursPerWeek || newSub.totalHours} hrs/week assigned to ${newSub.facultyName || newSub.faculty}`,
      time: "Just now",
    }, ...prev]);
  };

  const handleUpdateSemesterConfig = (updates) => {
    setSemesterConfig((prev) => ({ ...prev, ...updates }));
  };

  // Calls the real engine-backed endpoint when logged in; in demo mode
  // there's nothing to call, so it resolves immediately and the existing
  // simulated progress UI in TimetableGenerator is all the user sees.
  const handleGenerateTimetable = useCallback(async ({ department, semester, days = 6, periodsPerDay = 9, breakPeriods = [5] } = {}) => {
    if (!liveMode) return;
    const dept = department || selectedDepartment;
    const sem = semester || "Sem 5";
    try {
      const result = await timetableApi.generate({
        department: dept,
        semester: sem,
        days,
        periods_per_day: periodsPerDay,
        break_periods: breakPeriods,
      });
      setTimetable(
        timetableFromApi(result, {
          facultyById: byId(facultyList),
          subjectsById: byId(subjects),
          roomsById: byId(rooms),
        })
      );
      setAuditLogs((prev) => [{
        id: `a-${Date.now()}`,
        type: "success",
        title: "Timetable generated by scheduling engine",
        desc: `${result.entries.length} classes placed for ${dept} • ${sem} with zero constraint conflicts`,
        time: "Just now",
      }, ...prev]);
      return result;
    } catch (err) {
      if (err instanceof ApiError && err.status === 422) {
        const thrown = new Error(err.detail?.message || "Generation failed");
        thrown.reasons = err.detail?.reasons || [];
        throw thrown;
      }
      throw err;
    }
  }, [liveMode, selectedDepartment, facultyList, subjects, rooms]);

  const handlePublishTimetable = async (semester = "Sem 5") => {
    if (liveMode) {
      try {
        await timetableApi.publish(selectedDepartment, semester);
      } catch (err) {
        const reasons = err instanceof ApiError ? err.detail?.reasons : null;
        setAuditLogs((prev) => [
          {
            id: `a-${Date.now()}`,
            type: "error",
            title: "Publish blocked by the engine",
            desc: (reasons || [err.message]).join("; "),
            time: "Just now",
          },
          ...prev,
        ]);
        return;
      }
    }

    const newLog = {
      id: `a-${Date.now()}`,
      type: "success",
      title: "Timetable v3.4 Published to University ERP",
      desc: "Mumbai University master sync updated for Computer Science & IT divisions",
      time: "Just now",
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Render main content area depending on currentTab and currentRole
  const renderContent = () => {
    if (currentTab === "scheduling-engine") {
      return (
        <TimetableGenerator
          subjects={subjects}
          timetable={timetable}
          facultyList={facultyList}
          roomsList={rooms}
          semesterConfig={semesterConfig}
          selectedDepartment={selectedDepartment}
          onDepartmentChange={setSelectedDepartment}
          onUpdateSemesterConfig={handleUpdateSemesterConfig}
          onAddSubject={handleAddSubject}
          onUpdateSubject={handleUpdateSubject}
          onDeleteSubject={handleDeleteSubject}
          onAddFaculty={handleAddFaculty}
          onSemesterChange={handleLoadTimetable}
          currentRole={currentRole}
          onGenerateTimetable={handleGenerateTimetable}
          onNavigateTab={setCurrentTab}
        />
      );
    }

    if (currentTab === "faculty-and-staff") {
      return <FacultyStaffList facultyList={facultyList} />;
    }

    if (currentTab === "leave-and-substitutions") {
      return (
        <LeaveAndSubstitutions
          leaveRequests={leaveRequests}
          facultyList={facultyList}
          onAssignProxy={handleAssignProxy}
          onApproveLeave={handleAssignProxy}
        />
      );
    }

    // No dashboard, campus-intelligence, feedback, or export pages exist.
    // The scheduler is the first and default application workspace.
    return (
      <TimetableGenerator
        subjects={subjects}
        timetable={timetable}
        facultyList={facultyList}
        roomsList={rooms}
        semesterConfig={semesterConfig}
        selectedDepartment={selectedDepartment}
        onDepartmentChange={setSelectedDepartment}
        onUpdateSemesterConfig={handleUpdateSemesterConfig}
        onAddSubject={handleAddSubject}
        onUpdateSubject={handleUpdateSubject}
        onDeleteSubject={handleDeleteSubject}
        onAddFaculty={handleAddFaculty}
        onSemesterChange={handleLoadTimetable}
        currentRole={currentRole}
        onGenerateTimetable={handleGenerateTimetable}
        onNavigateTab={setCurrentTab}
      />
    );
  };

  if (loading) {
    return (
      <div className="bg-background min-h-screen flex items-center justify-center">
        <span className="material-symbols-outlined text-primary text-4xl animate-spin">progress_activity</span>
      </div>
    );
  }

  if (!user && !demoMode) {
    return <Login onDemoMode={() => setDemoMode(true)} />;
  }

  return (
    <div className="bg-background font-sans text-on-surface min-h-screen flex">
      {/* Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex flex-col min-h-screen lg:pl-72 transition-all">
        <TopHeader
          currentRoleUser={currentUser}
          onOpenMobileSidebar={() => setIsMobileSidebarOpen(true)}
          selectedDepartment={selectedDepartment}
          onDepartmentChange={setSelectedDepartment}
          notificationCount={leaveRequests.filter((l) => l.status === "PENDING_PROXY").length}
          onOpenNotifications={() => setIsNotificationModalOpen(true)}
          onSignOut={liveMode ? logout : undefined}
        />

        <main className="flex-1 pt-20 px-4 sm:px-8 py-6 w-full">
          {renderContent()}
        </main>
      </div>

      {/* Notifications Drawer Modal */}
      <Modal
        isOpen={isNotificationModalOpen}
        onClose={() => setIsNotificationModalOpen(false)}
        title="Administrative Notifications & Broadcasts"
        subtitle="Administrative alerts and scheduling updates"
      >
        <div className="space-y-3">
          {auditLogs.slice(0, 5).map((log) => (
            <div
              key={log.id}
              className="p-3.5 rounded-xl bg-surface-container-low border border-outline-variant/30 flex items-start gap-3"
            >
              <div className="w-2.5 h-2.5 rounded-full bg-secondary mt-1.5 shrink-0" />
              <div>
                <h4 className="font-label-md font-bold text-on-surface">{log.title}</h4>
                <p className="font-body-sm text-on-surface-variant mt-0.5">{log.desc}</p>
                <span className="font-label-sm text-outline mt-1 block">{log.time}</span>
              </div>
            </div>
          ))}
          <div className="pt-2 flex justify-end">
            <button
              onClick={() => setIsNotificationModalOpen(false)}
              className="px-4 py-2 rounded-xl bg-primary text-on-primary font-label-md font-bold"
            >
              Close Alerts
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
