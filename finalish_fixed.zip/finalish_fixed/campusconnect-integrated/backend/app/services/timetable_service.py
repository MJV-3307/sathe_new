"""Adapts Beanie documents to the framework-free timetable_engine and back.

Keeps app/timetable_engine.py importable and unit-testable with zero
FastAPI/Beanie knowledge, per the note at the top of that module.
"""
from __future__ import annotations

from app.models.faculty import Faculty
from app.models.room import Room
from app.models.subject import Subject
from app.models.timetable import Timetable, TimetableEntry
from app.timetable_engine import (
    ConflictError,
    Entry,
    FacultyInfo,
    GenerationError,
    RoomInfo,
    Slot,
    SubjectRequirement,
    conflicts_for_candidate,
    generate_timetable,
    move_entry,
    publish,
    validate_timetable,
)

__all__ = [
    "ConflictError",
    "GenerationError",
    "generate_for_department",
    "revalidate",
    "move_timetable_entry",
    "publish_timetable",
]


async def _load_maps(department: str, semester: str | None = None) -> tuple[
    dict[str, FacultyInfo], dict[str, RoomInfo], dict[str, SubjectRequirement]
]:
    faculty_docs = await Faculty.find(Faculty.department == department).to_list()
    room_docs = await Room.find_all().to_list()  # rooms aren't department-scoped
    subject_docs = await Subject.find(Subject.department == department).to_list()
    if semester:
        subject_docs = [s for s in subject_docs if s.semester == semester]

    faculty_map = {
        str(f.id): FacultyInfo(
            id=str(f.id),
            name=f.name,
            department=f.department,
            subject_ids=set(f.subject_ids),
            unavailable={Slot(s.day, s.period) for s in f.unavailable},
            max_classes_per_day=f.max_classes_per_day,
        )
        for f in faculty_docs
    }
    room_map = {
        str(r.id): RoomInfo(id=str(r.id), name=r.name, type=r.type, capacity=r.capacity)
        for r in room_docs
    }
    subject_map = {
        str(s.id): SubjectRequirement(
            id=str(s.id),
            name=s.name,
            department=s.department,
            semester=s.semester,
            faculty_id=s.faculty_id,
            hours_per_week=s.hours_per_week,
            requires_lab=s.requires_lab,
            student_count=s.student_count,
        )
        for s in subject_docs
    }
    return faculty_map, room_map, subject_map


def _entries_to_docs(entries: list[Entry]) -> list[TimetableEntry]:
    return [
        TimetableEntry(
            day=e.day,
            period=e.period,
            subject_id=e.subject_id,
            faculty_id=e.faculty_id,
            room_id=e.room_id,
            semester=e.semester,
        )
        for e in entries
    ]


def _docs_to_entries(docs: list[TimetableEntry]) -> list[Entry]:
    return [
        Entry(
            day=d.day,
            period=d.period,
            subject_id=d.subject_id,
            faculty_id=d.faculty_id,
            room_id=d.room_id,
            semester=d.semester,
        )
        for d in docs
    ]


async def generate_for_department(
    department: str,
    semester: str,
    days: int = 6,
    periods_per_day: int = 9,
    break_periods: set[int] | None = None,
) -> Timetable:
    """Generate a fresh timetable for one department+semester and persist it
    as the current (unpublished) working copy. Raises GenerationError
    (unchanged) if a complete conflict-free schedule can't be produced —
    callers should surface `.reasons` to the user.
    """
    faculty_map, room_map, subject_map = await _load_maps(department, semester)
    dept_subjects = list(subject_map.values())

    if not dept_subjects:
        raise GenerationError(
            [f"No subjects are stored for department '{department}' and {semester}. Add subjects first."],
            [],
        )

    entries = generate_timetable(
        dept_subjects, faculty_map, room_map, days=days,
        periods_per_day=periods_per_day, break_periods=break_periods,
    )

    doc = await Timetable.find_one(
        Timetable.department == department, Timetable.semester == semester
    )
    if doc is None:
        doc = Timetable(department=department, semester=semester)
    doc.entries = _entries_to_docs(entries)
    doc.is_published = False
    doc.generated_at = Timetable.now()
    await doc.save()
    return doc


async def revalidate(department: str, semester: str) -> list[str]:
    """Re-run full validation against the currently stored (unpublished or
    published) timetable. Returns a list of conflict reasons (empty = OK).
    """
    faculty_map, room_map, subject_map = await _load_maps(department, semester)
    doc = await Timetable.find_one(
        Timetable.department == department, Timetable.semester == semester
    )
    if doc is None:
        return []
    entries = _docs_to_entries(doc.entries)
    return validate_timetable(entries, faculty_map, room_map, subject_map)


async def move_timetable_entry(
    department: str,
    semester: str,
    target: TimetableEntry,
    new_day: int,
    new_period: int,
    new_room_id: str | None,
    new_faculty_id: str | None,
) -> Timetable:
    """Move/drag one class. Raises ConflictError and leaves storage
    untouched if the move is invalid.
    """
    faculty_map, room_map, subject_map = await _load_maps(department, semester)
    doc = await Timetable.find_one(
        Timetable.department == department, Timetable.semester == semester
    )
    if doc is None:
        raise ConflictError(["No timetable exists yet for this department/semester"])

    entries = _docs_to_entries(doc.entries)
    target_entry = Entry(
        day=target.day, period=target.period, subject_id=target.subject_id,
        faculty_id=target.faculty_id, room_id=target.room_id, semester=target.semester,
    )
    new_entries = move_entry(
        entries, target_entry, new_day, new_period, new_room_id, new_faculty_id,
        faculty_map, room_map, subject_map,
    )
    doc.entries = _entries_to_docs(new_entries)
    doc.is_published = False
    await doc.save()
    return doc


async def publish_timetable(department: str, semester: str) -> Timetable:
    """Gate used by POST /timetable/publish. Raises ConflictError (with
    every reason) if the current working copy isn't publishable.
    """
    faculty_map, room_map, subject_map = await _load_maps(department, semester)
    doc = await Timetable.find_one(
        Timetable.department == department, Timetable.semester == semester
    )
    if doc is None:
        raise ConflictError(["No timetable exists yet for this department/semester"])

    entries = _docs_to_entries(doc.entries)
    publish(entries, faculty_map, room_map, subject_map)  # raises on failure

    doc.is_published = True
    doc.published_at = Timetable.now()
    await doc.save()
    return doc
