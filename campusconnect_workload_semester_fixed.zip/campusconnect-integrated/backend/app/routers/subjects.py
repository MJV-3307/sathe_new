from fastapi import APIRouter, Depends, HTTPException, status

from app.dependencies.roles import require_admin_or_faculty
from app.models.faculty import Faculty
from app.models.subject import Subject
from app.models.timetable import Timetable
from app.schemas_domain import SubjectIn, SubjectOut
from app.users import current_active_user

router = APIRouter()


def _to_out(doc: Subject) -> SubjectOut:
    return SubjectOut(id=str(doc.id), **doc.model_dump(exclude={"id"}))


@router.get("", response_model=list[SubjectOut])
async def list_subjects(
    department: str | None = None,
    semester: str | None = None,
    _=Depends(current_active_user),
):
    query = Subject.find_all()
    if department:
        query = Subject.find(Subject.department == department)
    docs = await query.to_list()
    if semester:
        docs = [d for d in docs if d.semester == semester]
    return [_to_out(d) for d in docs]


async def _sync_faculty_subject_links(subject_id: str, old_faculty_id: str | None, new_faculty_id: str | None):
    """Keep faculty.subject_ids consistent when a subject is reassigned."""
    if old_faculty_id and old_faculty_id != new_faculty_id:
        old = await Faculty.get(old_faculty_id)
        if old is not None:
            old.subject_ids = [sid for sid in (old.subject_ids or []) if sid != subject_id]
            await old.save()
    if new_faculty_id:
        new = await Faculty.get(new_faculty_id)
        if new is None:
            raise HTTPException(status_code=400, detail="Selected faculty member does not exist")
        ids = list(new.subject_ids or [])
        if subject_id not in ids:
            ids.append(subject_id)
        new.subject_ids = ids
        await new.save()


@router.post("", response_model=SubjectOut, status_code=status.HTTP_201_CREATED)
async def create_subject(payload: SubjectIn, _=Depends(require_admin_or_faculty)):
    faculty = await Faculty.get(payload.faculty_id)
    if faculty is None:
        raise HTTPException(status_code=400, detail="Selected faculty member does not exist")
    if faculty.department != payload.department:
        raise HTTPException(status_code=400, detail="Faculty and subject must belong to the same department")
    doc = Subject(**payload.model_dump())
    await doc.insert()
    await _sync_faculty_subject_links(str(doc.id), None, doc.faculty_id)
    return _to_out(doc)


@router.patch("/{subject_id}", response_model=SubjectOut)
async def update_subject(subject_id: str, payload: SubjectIn, _=Depends(require_admin_or_faculty)):
    doc = await Subject.get(subject_id)
    if doc is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subject not found")
    faculty = await Faculty.get(payload.faculty_id)
    if faculty is None:
        raise HTTPException(status_code=400, detail="Selected faculty member does not exist")
    if faculty.department != payload.department:
        raise HTTPException(status_code=400, detail="Faculty and subject must belong to the same department")

    old_faculty_id = doc.faculty_id
    old_department = doc.department
    for field, value in payload.model_dump().items():
        setattr(doc, field, value)
    await doc.save()
    await _sync_faculty_subject_links(str(doc.id), old_faculty_id, doc.faculty_id)

    # Any timetable containing this subject is now stale. Keep it as a draft
    # so the admin must regenerate before publishing the changed workload.
    for tt in await Timetable.find_all().to_list():
        if tt.department in {old_department, doc.department} and any(e.subject_id == str(doc.id) for e in tt.entries):
            tt.is_published = False
            tt.entries = [e for e in tt.entries if e.subject_id != str(doc.id)]
            await tt.save()
    return _to_out(doc)


@router.delete("/{subject_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_subject(subject_id: str, _=Depends(require_admin_or_faculty)):
    doc = await Subject.get(subject_id)
    if doc is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Subject not found")
    await _sync_faculty_subject_links(str(doc.id), doc.faculty_id, None)
    for tt in await Timetable.find_all().to_list():
        if tt.department == doc.department and any(e.subject_id == str(doc.id) for e in tt.entries):
            tt.is_published = False
            tt.entries = [e for e in tt.entries if e.subject_id != str(doc.id)]
            await tt.save()
    await doc.delete()
